import { permission } from './permis'

// 自定义指令
export const directives = {
  permission
}