<template>
  <div>2</div>
</template>

<script>
export default {

}
</script>

<style>

</style>